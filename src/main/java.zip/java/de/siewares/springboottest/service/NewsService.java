/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package de.siewares.springboottest.service;

import de.siewares.springboottest.entity.News;
import org.springframework.beans.factory.annotation.Autowired;
import de.siewares.springboottest.repository.NewsRepository;
import org.springframework.stereotype.Service;

/**
 *
 * @author Klaus
 */
@Service
public class NewsService {
  
  @Autowired
  private NewsRepository newsRepository;
  
  public void save(News news)  {
    newsRepository.save(news);
  }
  
}
